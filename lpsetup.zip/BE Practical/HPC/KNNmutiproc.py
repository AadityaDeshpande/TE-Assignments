import math
import multiprocessing
import time
from itertools import chain 

distance=[]
# Dictionary of training points having two keys - 0 and 1 
	# key 0 have points belong to class 0 
	# key 1 have points belong to class 1 

points = {0:[(1,12),(2,5),(3,6),(3,10),(3.5,8),(2,11),(2,9),(1,7)], 
1:[(5,3),(3,2),(1.5,9),(7,2),(6,1),(3.8,1),(5.6,4),(4,2),(2,5)]} 

	# testing point p(x,y) 
p = (2.5,7) 

	# Number of neighbours 
k = 3
def myfun(group):
  distance
  global points
  for feature in points[group]: 

			#calculate the euclidean distance of p from training points 
			euclidean_distance = math.sqrt((feature[0]-p[0])**2 +(feature[1]-p[1])**2) 

			# Add a touple of form (distance,group) in the distance list 
			distance.append((euclidean_distance,group)) 
  return distance
def classifyAPoint(points,p,k=3): 
	''' 
	This function finds classification of p using 
	k nearest neighbour algorithm. It assumes only two 
	groups and returns 0 if p belongs to group 0, else 
	1 (belongs to group 1). 
	Parameters - 
		points : Dictionary of training points having two keys - 0 and 1 
				Each key have a list of training data points belong to that 
		p : A touple ,test data point of form (x,y) 
		k : number of nearest neighbour to consider, default is 3 
	'''

	global distance
	pool = multiprocessing.Pool()
	distance=pool.map(myfun, (group for group in points ))
	distance=list(chain.from_iterable(distance))
	#time.sleep(1)
	#for group in points:
	#	for feature in points[group]: 

			#calculate the euclidean distance of p from training points 
#			euclidean_distance = math.sqrt((feature[0]-p[0])**2 +(feature[1]-p[1])**2) 

			# Add a touple of form (distance,group) in the distance list 
#			distance.append((euclidean_distance,group)) 

	# sort the distance list in ascending order 
	# and select first k distances
	print(distance) 
	distance = sorted(distance)[:k] 

	freq1 = 0 #frequency of group 0 
	freq2 = 0 #frequency og group 1 

	for d in distance: 
		if d[1] == 0: 
			freq1 += 1
		elif d[1] == 1: 
			freq2 += 1

	return 0 if freq1>freq2 else 1

# driver function 
def main(): 

	

	print("The value classified to unknown point is: {}".\
		format(classifyAPoint(points,p,k))) 

if __name__ == '__main__': 
	main() 
	
